import boto3

def lambda_handler(event, context):
    tenant_id = event['body']['tenant_id']
    alumno_id = event['body']['alumno_id']
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('t_alumnos')
    response = table.get_item(
        Key={'tenant_id': tenant_id, 'alumno_id': alumno_id}
    )
    if 'Item' not in response:
        return {'statusCode': 404, 'mensaje': 'Alumno no encontrado'}
    return {'statusCode': 200, 'alumno': response['Item']}
